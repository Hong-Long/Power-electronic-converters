/*
 * bridgelessPFC.c
 *
 *  Created on: Aug 6, 2020
 *      Author: a0485593
 */
#include <pfc1phttpl.h>

/*****************************Global Variables*****************************/
#pragma SET_DATA_SECTION("controlVariables")
// RAMP to generate forced angle when grid is not present
PFC1PHTTPL_RAMP PFC1PHTTPL_rgen;

//PI parameters
volatile PFC1PHTTPL_GI PFC1PHTTPL_gi;
PFC1PHTTPL_GV PFC1PHTTPL_gv;

//SPLL
SPLL_1PH_SOGI PFC1PHTTPL_spll1;
SPLL_1PH_NOTCH PFC1PHTTPL_spll2;
SPLL_1PH_SOGI_FLL PFC1PHTTPL_spll3;
PFC1PHTTPL_NOTCH_2P2Z PFC1PHTTPL_notch1, PFC1PHTTPL_notch2;

// Sine analyzer block for RMS Volt, Curr and Power measurements
volatile POWER_MEAS_SINE_ANALYZER PFC1PHTTPL_sine_mains;

// Display Values
volatile float32_t PFC1PHTTPL_guiVbus_Volts;
float32_t PFC1PHTTPL_guiVbusMax_Volts;
volatile float32_t PFC1PHTTPL_guiVrms_Volts;
float32_t PFC1PHTTPL_guiACFreq_Hz;
float32_t PFC1PHTTPL_guiPrms_W;
float32_t PFC1PHTTPL_guiIrms_Amps;
float32_t PFC1PHTTPL_guiVavg_Volts;
float32_t PFC1PHTTPL_guiFreqAvg_Hz;
float32_t PFC1PHTTPL_guiVema_Volts;
float32_t PFC1PHTTPL_guiVrmsEMAvg_Volts;
float32_t PFC1PHTTPL_guiVin_Volts;
// 10 corresponds to 100ns dead time
uint32_t PFC1PHTTPL_dbRED_SetValue_ticks;
uint32_t PFC1PHTTPL_dbRED_SetValue_Temp_ticks;
volatile uint32_t PFC1PHTTPL_dbFED_SetValue_ticks;
uint32_t PFC1PHTTPL_dbRED_Min_ticks;
uint32_t PFC1PHTTPL_dbRED_Max_ticks;

// AC Current Measurement
volatile float32_t PFC1PHTTPL_iLMeas_pu,PFC1PHTTPL_iLVrefMeas_pu;
volatile float32_t PFC1PHTTPL_iLRef_pu;
float32_t PFC1PHTTPL_iLMeasScaled_Amps;
float32_t PFC1PHTTPL_iLMeasOffset_pu;
float32_t PFC1PHTTPL_iLRef_Inst_pu, PFC1PHTTPL_iLRef_Inst_prev_pu;
//Output Voltage measurement
volatile float32_t PFC1PHTTPL_vBusMeas_pu;
float32_t PFC1PHTTPL_vBusMeasOffset_pu;
float32_t PFC1PHTTPL_vBusRef_pu;
float32_t PFC1PHTTPL_vBusMeasFiltered_notch1_pu;
float32_t PFC1PHTTPL_vBusMeasFiltered_notch2_pu;
//Input voltage measurement
volatile float32_t PFC1PHTTPL_vACLMeas_pu, PFC1PHTTPL_vACNMeas_pu, PFC1PHTTPL_vACMeas_pu;
float32_t PFC1PHTTPL_vACLMeasOffset_pu, PFC1PHTTPL_vACNMeasOffset_pu, PFC1PHTTPL_vACMeasOffset_pu;

//Duty relation.
volatile float32_t PFC1PHTTPL_dutyPU,PFC1PHTTPL_dutyPU_DC;
volatile float32_t PFC1PHTTPL_thetaOffset_pu;
//Control flags.
int32_t PFC1PHTTPL_closeGiLoop,PFC1PHTTPL_closeGvLoop;
volatile int32_t PFC1PHTTPL_relayConnect;
int32_t PFC1PHTTPL_autoStartSlew,PFC1PHTTPL_firstTimeGvLoop;
// Flags for detecting ZCD
volatile float32_t PFC1PHTTPL_acSine;
float32_t PFC1PHTTPL_acSine_Prev;
float32_t PFC1PHTTPL_threshold_PZC1,PFC1PHTTPL_threshold_PZC2;
float32_t PFC1PHTTPL_threshold_NZC1,PFC1PHTTPL_threshold_NZC2;
// 1 if using non linear voltage loop, 0 otherwise
uint32_t PFC1PHTTPL_nonLinearVoltageLoopFlag;
//Filtered DC&AC voltage measurement
float32_t PFC1PHTTPL_vBusMeasAvg_pu;
float32_t PFC1PHTTPL_vACRmsMeasAvg_pu;
//inductor_voltage_drop_feedforward
float32_t PFC1PHTTPL_inductor_voltage_drop_feedforward;
//voltage set point
float32_t PFC1PHTTPL_vBusRefSlewed_pu;
//Other display Values
float32_t PFC1PHTTPL_guiIL_Amps;
float32_t PFC1PHTTPL_guiPowerFactor;
float32_t PFC1PHTTPL_guiVA_VA;
//Soft start in pwmSwState switch
float32_t PFC1PHTTPL_softStartDuty_ticks;
int32_t PFC1PHTTPL_stateSlew=0;
int32_t PFC1PHTTPL_stateSlewMax;
volatile uint32_t PFC1PHTTPL_softStartDeadBandFED_ticks;
//Controller output.
volatile float32_t PFC1PHTTPL_gi_out;
float32_t PFC1PHTTPL_gv_out, PFC1PHTTPL_gi_pi_ki;
//Status flags.
PFC1PHTTPL_buildLevel PFC1PHTTPL_build_Level;
PFC1PHTTPL_boardState PFC1PHTTPL_board_State;
PFC1PHTTPL_boardStatus PFC1PHTTPL_board_Status;
PFC1PHTTPL_pwmSwState PFC1PHTTPL_pwm_SwState;
//Filter BUS voltage sensed result.
volatile float32_t PFC1PHTTPL_vBusMeasBuff_pu[10];
float32_t PFC1PHTTPL_vBusMeasFiltered_pu;
int32_t PFC1PHTTPL_vBusMeasBuffIndex=0;
//SPLL result. Vin direction.
float32_t PFC1PHTTPL_spll_sine,PFC1PHTTPL_spll_cosine;
int32_t PFC1PHTTPL_ac_sign_filtered;
//Voltage loop flag.
float32_t PFC1PHTTPL_vBusError_pu;

float32_t PFC1PHTTPL_phase2ScaleFactor;
//LLC shutdown flag.
int16_t PFC1PHTTPL_llcShutdownFlag;
//Relay control.
uint16_t PFC1PHTTPL_relay_count;
// Variables used to calibrate measurement offsets
//Offset filter coefficient K1: 0.05/(T+0.05);
float32_t PFC1PHTTPL_k1;
//Offset filter coefficient K2: T/(T+0.05)
float32_t PFC1PHTTPL_k2;
volatile int16_t PFC1PHTTPL_highPowerTrans_flag;
#pragma SET_DATA_SECTION()

//Datalogger
DLOG_4CH PFC1PHTTPL_dLog1;
float32_t PFC1PHTTPL_dBuff1[100], PFC1PHTTPL_dBuff2[100], PFC1PHTTPL_dBuff3[100], PFC1PHTTPL_dBuff4[100];//3
float32_t PFC1PHTTPL_dVal1, PFC1PHTTPL_dVal2, PFC1PHTTPL_dVal3, PFC1PHTTPL_dVal4;

//--- SFRA Related Variables ---
#if PFC1PHTTPL_SFRA_TYPE!=PFC1PHTTPL_SFRA_DISABLED
float32_t PFC1PHTTPL_plantMagVect[PFC1PHTTPL_SFRA_FREQ_LENGTH];
float32_t PFC1PHTTPL_plantPhaseVect[PFC1PHTTPL_SFRA_FREQ_LENGTH];
float32_t PFC1PHTTPL_olMagVect[PFC1PHTTPL_SFRA_FREQ_LENGTH];
float32_t PFC1PHTTPL_olPhaseVect[PFC1PHTTPL_SFRA_FREQ_LENGTH];
float32_t PFC1PHTTPL_freqVect[PFC1PHTTPL_SFRA_FREQ_LENGTH];
#endif

SFRA_F32 PFC1PHTTPL_sfra1;
int16_t i;
volatile int16_t PFC1PHTTPL_initializationFlag;

//User monitoring variables.
volatile float32_t *PFC1PHTTPL_iqGraphIdTab1[5] = {
&(PFC1PHTTPL_acSine),/*0*/&(PFC1PHTTPL_vACMeas_pu),/*1*/&(PFC1PHTTPL_dutyPU ),/*2*/&(PFC1PHTTPL_spll_sine),/*3*/&(PFC1PHTTPL_acSine),/*4*/};
uint16_t PFC1PHTTPL_uGraphID=1;
uint16_t PFC1PHTTPL_uGraphID2=2;
uint16_t PFC1PHTTPL_IsrTicker= 0;
uint16_t PFC1PHTTPL_usShowCnt = 0;
uint16_t PFC1PHTTPL_usShowDiv=40;
float32_t PFC1PHTTPL_Watchvalue[100];// Watchvalue2[100];//,Watchvalue3[100], Watchvalue4[100];
float32_t PFC1PHTTPL_Watchvalue1[100];// Watchvalue2[100];//,Watchvalue3[100], Watchvalue4[100];

//User debug graph array.
#if PFC1PHTTPL_DEBUG_CHIP==F28004x
#pragma SET_DATA_SECTION("graphArray1")
float32_t PFC1PHTTPL_graphArrayWatchValue1[1600];
uint16_t PFC1PHTTPL_graphArrayWatchValueindex1;
uint16_t PFC1PHTTPL_faultTriggerFlag1;//0 No fault 1 Fault
#pragma SET_DATA_SECTION()
#pragma SET_DATA_SECTION("graphArray3")
float32_t PFC1PHTTPL_graphArrayWatchValue2[1600];
#pragma SET_DATA_SECTION()
#pragma SET_DATA_SECTION("graphArray2")
float32_t PFC1PHTTPL_graphArrayWatchValue3[2000];
float32_t PFC1PHTTPL_graphArrayWatchValue4[2000];
uint16_t PFC1PHTTPL_graphArrayWatchValueindex2;
uint16_t PFC1PHTTPL_faultTriggerFlag2;//0 No fault 1 Fault
#pragma SET_DATA_SECTION()
#endif

void PFC1PHTTPL_globalVariablesInit(void)
{
    /*Open loop check when PFC1PHTTPL_INCR_BUILD=1. Generate ramp wave.*/
    RAMPGEN_reset(&PFC1PHTTPL_rgen);
    RAMPGEN_config(&PFC1PHTTPL_rgen,
                   PFC1PHTTPL_CONTROL_ISR_FREQUENCY,
                   PFC1PHTTPL_AC_FREQ);

    /*PI parameter for current and voltage loop*/

    #if PFC1PHTTPL_CONTROL_RUNNING_ON == C28x_CORE
    PFC1PHTTPL_gi.Kp=PFC1PHTTPL_GI_PI_KP;
    PFC1PHTTPL_gi.Ki=PFC1PHTTPL_GI_PI_KI;
    #endif
    #if PFC1PHTTPL_CONTROL_RUNNING_ON == CLA_CORE
    PFC1PHTTPL_gi.Kp=PFC1PHTTPL_GI_PI_KP_CLAL;
    PFC1PHTTPL_gi.Ki=PFC1PHTTPL_GI_PI_KI_CLAL;
    #endif
    PFC1PHTTPL_gi.Umax=PFC1PHTTPL_GI_PI_MAX;
    PFC1PHTTPL_gi.Umin=PFC1PHTTPL_GI_PI_MIN;
    PFC1PHTTPL_gi.i10=0;
    PFC1PHTTPL_gi.i6=0;
    PFC1PHTTPL_gi_pi_ki=PFC1PHTTPL_GI_PI_KI;

    PFC1PHTTPL_gv.Ki=PFC1PHTTPL_GV_PI_KI;
    PFC1PHTTPL_gv.Kp=PFC1PHTTPL_GV_PI_KP;
    PFC1PHTTPL_gv.Umax=PFC1PHTTPL_GV_PI_MAX;
    PFC1PHTTPL_gv.Umin=PFC1PHTTPL_GV_PI_MIN;
    PFC1PHTTPL_gv.i10=0;
    PFC1PHTTPL_gv.i6=0;

    /*SPLL parameters. Use SPLL_METHOD_SELECT to select PLL method*/
    SPLL_1PH_SOGI_reset(&PFC1PHTTPL_spll1);
    SPLL_1PH_SOGI_config(&PFC1PHTTPL_spll1,
                         PFC1PHTTPL_AC_FREQ,
                         PFC1PHTTPL_CONTROL_ISR_FREQUENCY,
                         (float32_t)(222.2862),
                         (float32_t)(-222.034));

    SPLL_1PH_NOTCH_reset(&PFC1PHTTPL_spll2);
    SPLL_1PH_NOTCH_config(&PFC1PHTTPL_spll2,
                          PFC1PHTTPL_AC_FREQ,
                          PFC1PHTTPL_CONTROL_ISR_FREQUENCY,
                          (float32_t)(222.2862),
                          (float32_t)(-222.034),
                          (float32_t) 0.25,
                          (float32_t) 0.00001);

    SPLL_1PH_SOGI_FLL_reset(&PFC1PHTTPL_spll3);
    SPLL_1PH_SOGI_FLL_config(&PFC1PHTTPL_spll3,
                             PFC1PHTTPL_AC_FREQ,
                             PFC1PHTTPL_CONTROL_ISR_FREQUENCY,
                             (float32_t)(222.2862),
                             (float32_t)(-222.034),
                             (float32_t) 0.5,
                             (float32_t) 20000);

    /*Sine analyzer initialization*/
    POWER_MEAS_SINE_ANALYZER_reset(&PFC1PHTTPL_sine_mains);
    POWER_MEAS_SINE_ANALYZER_config(&PFC1PHTTPL_sine_mains,
                                    PFC1PHTTPL_INSTRUMENTATION_ISR_FREQUENCY,
                                    (float32_t)0.08,
                                    (float32_t)GRID_MAX_FREQ,
                                    (float32_t)GRID_MIN_FREQ);
    /*2nd order Direct Form 2 controller processing sensed BUS voltage signal*/
    computeNotchFltrCoeff( &PFC1PHTTPL_notch1, (float32_t)(PFC1PHTTPL_INSTRUMENTATION_ISR_FREQUENCY),
                           (float32_t)(PFC1PHTTPL_AC_FREQ*2.0f) , 0.25f, 0.00001f);
    computeNotchFltrCoeff( &PFC1PHTTPL_notch2, (float32_t)(PFC1PHTTPL_INSTRUMENTATION_ISR_FREQUENCY),
                           (float32_t)(PFC1PHTTPL_AC_FREQ*2.0f) , 0.25f, 0.00001f);
    PFC1PHTTPL_notch1.x1=0;
    PFC1PHTTPL_notch1.x2=0;
    PFC1PHTTPL_notch2.x1=0;
    PFC1PHTTPL_notch2.x2=0;

    /*Data log: graphically observe system variables */
    DLOG_4CH_reset(&PFC1PHTTPL_dLog1);
    DLOG_4CH_config(&PFC1PHTTPL_dLog1,
                    &PFC1PHTTPL_dVal1,&PFC1PHTTPL_dVal2,&PFC1PHTTPL_dVal3,&PFC1PHTTPL_dVal4,
                    PFC1PHTTPL_dBuff1,PFC1PHTTPL_dBuff2,PFC1PHTTPL_dBuff3,PFC1PHTTPL_dBuff4,
                    100, 0.1f, 5);

    /*Gui Variables initialize*/
    PFC1PHTTPL_guiVbus_Volts=0;
    PFC1PHTTPL_guiACFreq_Hz=0;
    PFC1PHTTPL_guiPrms_W=0;
    PFC1PHTTPL_guiIrms_Amps=0;
    PFC1PHTTPL_guiVrms_Volts=0;
    PFC1PHTTPL_guiVavg_Volts=0;
    PFC1PHTTPL_guiFreqAvg_Hz=0;
    PFC1PHTTPL_guiVema_Volts=0;
    PFC1PHTTPL_guiVbusMax_Volts=440;
    PFC1PHTTPL_guiVrmsEMAvg_Volts=0;
    PFC1PHTTPL_guiVin_Volts=0;


    /*A.D.T Variables: Dead band RED and FED set*/
    PFC1PHTTPL_dbFED_SetValue_ticks = PFC1PHTTPL_HIGH_FREQ_PWM_DEADBAND_FED_COUNT;
    PFC1PHTTPL_dbRED_SetValue_ticks = PFC1PHTTPL_HIGH_FREQ_PWM_DEADBAND_RED_COUNT;
    PFC1PHTTPL_dbRED_SetValue_Temp_ticks = PFC1PHTTPL_HIGH_FREQ_PWM_DEADBAND_RED_COUNT;
    PFC1PHTTPL_dbRED_Min_ticks=PFC1PHTTPL_HIGH_FREQ_PWM_DEADBAND_RED_MIN_COUNT;
    PFC1PHTTPL_dbRED_Max_ticks=PFC1PHTTPL_HIGH_FREQ_PWM_DEADBAND_RED_MAX_COUNT;


    /*Sample and loop variable initialization*/
    PFC1PHTTPL_iLMeas_pu=0;        //PU of inductor current sensed value.(-0.5~0.5). Used in control.
    PFC1PHTTPL_iLVrefMeas_pu=0;    //DC bias voltage (1.65V) in current sensed loop.
    PFC1PHTTPL_iLMeasOffset_pu=0;   //ADC result when inductor current=0. Use PFC1PHTTPL_calibrateOffset() to calculate.


    PFC1PHTTPL_vBusMeas_pu=0;          //PU of voltage sensed value.(0-1). Used in control.
    PFC1PHTTPL_vBusMeasOffset_pu=0;    //ADC result when BUS voltage=0. Do not use now.
    PFC1PHTTPL_vBusRef_pu=PFC1PHTTPL_VBUS_TYPICAL_VOLT/PFC1PHTTPL_VDCBUS_MAX_SENSE_VOLT;//Reference for PFC1PHTTPL_vBusRefSlewed_pu.
    PFC1PHTTPL_vBusMeasFiltered_notch1_pu=0;//Result of vBus after use one notch filter.
    PFC1PHTTPL_vBusMeasFiltered_notch2_pu=0;//Result of vBus after use two notch filter.

    PFC1PHTTPL_iLRef_pu=0.03f;        //Voltage loop PI output for current reference (do not contain phase of Vin).
    //Input voltage measurement

    PFC1PHTTPL_vACLMeas_pu=0;          //PU of Vin L line voltage sensed value.(0~1.
    PFC1PHTTPL_vACLMeasOffset_pu=0;     //ADC result when Vin=0. Do not use now.
    PFC1PHTTPL_vACNMeas_pu=0;          //PU of Vin L line voltage sensed value.(0~1).
    PFC1PHTTPL_vACNMeasOffset_pu=0;     //ADC result when Vin=0. Do not use now.
    PFC1PHTTPL_vACMeasOffset_pu=0;   //PFC1PHTTPL_vACNMeas_pu-PFC1PHTTPL_vACLMeas_pu result when Vin=0. Do not use now.

    PFC1PHTTPL_dutyPU=0;               //PU of duty for ePWM module.
    PFC1PHTTPL_dutyPU_DC=0;            //PU of duty for PFC1PHTTPL_DC_CHECK=1.
    PFC1PHTTPL_dutyPU_DC=0.5f;

    PFC1PHTTPL_thetaOffset_pu=0;          //Current loop reference adjust.
    /*Flags in ISR and idle loop tasks*/
    PFC1PHTTPL_closeGiLoop=0;          //Flag for close current control loop.
    PFC1PHTTPL_closeGvLoop=0;          //Flag for voltage current control loop.

    PFC1PHTTPL_relayConnect=0;           //Flag for control relay.
    PFC1PHTTPL_firstTimeGvLoop=1;      //Flag for set reference for voltage loop in the first time.
    PFC1PHTTPL_acSine=0;               //PFC1PHTTPL_acSine=PFC1PHTTPL_spll_sine=PFC1PHTTPL_spll1.sine. Use for (1)relay control (2)pwmSwState control (3) provide phase information.
    PFC1PHTTPL_acSine_Prev=0;           //Record last period phase of Vin.
    PFC1PHTTPL_autoStartSlew=0;        //Start steps in B2 tasks.
    PFC1PHTTPL_nonLinearVoltageLoopFlag=0;//Flag for change PI for voltage loop.

    /*Acsine threshold to switch pwmSwState*/
    PFC1PHTTPL_threshold_PZC1=PWM_SWITCHING_PZC1;
    PFC1PHTTPL_threshold_PZC2=PWM_SWITCHING_PZC2;
    PFC1PHTTPL_threshold_NZC1=PWM_SWITCHING_NZC1;
    PFC1PHTTPL_threshold_NZC2=PWM_SWITCHING_NZC2;

    /*Results after use digital LPF for vRms and vBus. Use in control loop*/
    PFC1PHTTPL_vACRmsMeasAvg_pu=0;
    PFC1PHTTPL_vBusMeasAvg_pu=0;

    /*pwmSwState*/
    PFC1PHTTPL_pwm_SwState.enum_pwmSwState=pwmSwState_defaultState;
    PFC1PHTTPL_stateSlewMax=10;
    /*LLC shut down flag*/
    PFC1PHTTPL_llcShutdownFlag=0;
    /*Relay control*/
    PFC1PHTTPL_relay_count=0;
    /*Calibrate measurement offsets*/
    PFC1PHTTPL_k1 = 0.998f;
    PFC1PHTTPL_k2 = 0.001999f;
    PFC1PHTTPL_phase2ScaleFactor=1.0f;
    /*CLA changable PI flag*/
    PFC1PHTTPL_highPowerTrans_flag=0;
    /*Graph debug*/
#if PFC1PHTTPL_DEBUG_CHIP==F28004x
    PFC1PHTTPL_graphArrayWatchValueindex1=0;
    PFC1PHTTPL_faultTriggerFlag1=0;
    PFC1PHTTPL_graphArrayWatchValueindex2=0;
    PFC1PHTTPL_faultTriggerFlag1=0;
#endif
}


//
//
//
void computeNotchFltrCoeff(DCL_DF22 *coeff, float32_t Fs, float32_t notch_freq,
                           float32_t c1, float32_t c2)
{
    float32_t temp1;
    float32_t temp2;
    float32_t wn2;
    float32_t Ts;
    Ts=1/Fs;

    // pre warp the notch frequency
    wn2=2*Fs*tanf(notch_freq* PI_VALUE*Ts);

    temp1= 4*Fs*Fs + 4* wn2 * c2 * Fs + wn2*wn2;
    temp2= 1/ ( 4*Fs*Fs + 4* wn2 * c1 * Fs + wn2*wn2);

    coeff->b0 = temp1* temp2;
    coeff->b1 = (-8*Fs*Fs + 2* wn2* wn2)* temp2;
    coeff->b2 = (4*Fs*Fs-4*wn2*c2*Fs+wn2*wn2)*temp2;
    coeff->a1 = (-8*Fs*Fs + 2* wn2* wn2)*temp2;
    coeff->a2 = (4*Fs*Fs-4*wn2*c1*Fs+wn2*wn2)*temp2;

}

//TODO updateBoardStatus()
void PFC1PHTTPL_updateBoardStatus()
{
    if(PFC1PHTTPL_board_Status.enum_boardStatus==boardStatus_NoFault)
    {
        if((PFC1PHTTPL_PWM_TRIP_STATUS(EPWM1_BASE)&EPWM_TZ_INTERRUPT_CBC)!=0 )
            PFC1PHTTPL_board_Status.enum_boardStatus=boardStatus_EmulatorStopTrip;
    }

}

//TODO updateBuildLevel()
void PFC1PHTTPL_updateBuildLevel()
{
#if PFC1PHTTPL_INCR_BUILD==1
    #if PFC1PHTTPL_DC_CHECK==1
        #if PFC1PHTTPL_CONTROL_RUNNING_ON == CLA_CORE
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel1_OpenLoop_DC_CLA;
        #else
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel1_OpenLoop_DC;
        #endif
    #else
        #if PFC1PHTTPL_CONTROL_RUNNING_ON == CLA_CORE
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel1_OpenLoop_AC_CLA;
        #else
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel1_OpenLoop_AC;
        #endif
    #endif
#elif PFC1PHTTPL_INCR_BUILD==2
    #if PFC1PHTTPL_DC_CHECK==1
        #if PFC1PHTTPL_CONTROL_RUNNING_ON == CLA_CORE
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel2_CurrentLoop_DC_CLA;
        #else
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel2_CurrentLoop_DC;
        #endif
    #else
        #if PFC1PHTTPL_CONTROL_RUNNING_ON == CLA_CORE
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel2_CurrentLoop_AC_CLA;
        #else
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel2_CurrentLoop_AC;
        #endif
    #endif
#elif PFC1PHTTPL_INCR_BUILD==3
    #if PFC1PHTTPL_DC_CHECK==1
       #if PFC1PHTTPL_CONTROL_RUNNING_ON == CLA_CORE
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel3_VoltageLoop_DC_CLA;
       #else
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel3_VoltageLoop_DC;
    #endif
    #else
        #if PFC1PHTTPL_CONTROL_RUNNING_ON == CLA_CORE
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel3_VoltageLoop_AC_CLA;
        #else
    PFC1PHTTPL_build_Level.enum_buildLevel=BuildLevel3_VoltageLoop_AC;
        #endif
    #endif
#endif

}

void PFC1PHTTPL_autoStartPFC()
{
#if PFC1PHTTPL_DC_CHECK==1
    if(PFC1PHTTPL_autoStartSlew<100)
        PFC1PHTTPL_autoStartSlew++;
#else
    if(PFC1PHTTPL_guiVrms_Volts >= 75.0f)  //ToDo:75
    {
        if(PFC1PHTTPL_autoStartSlew<5)
        {
            PFC1PHTTPL_autoStartSlew++;
        }

        if(PFC1PHTTPL_autoStartSlew==1)
        {
            PFC1PHTTPL_board_Status.enum_boardStatus=boardStatus_Idle;
            PFC1PHTTPL_pwm_SwState.enum_pwmSwState=pwmSwState_defaultState;
        }

        if(PFC1PHTTPL_autoStartSlew==2)
        {


            DINT;

            if(PFC1PHTTPL_sine_mains.acFreq>55)
            {
                PFC1PHTTPL_sine_mains.acFreq=60;
            }
            else
            {
                PFC1PHTTPL_sine_mains.acFreq=50;
            }

            SPLL_1PH_SOGI_config(&PFC1PHTTPL_spll1,
                                 PFC1PHTTPL_sine_mains.acFreq,
                                 PFC1PHTTPL_CONTROL_ISR_FREQUENCY,
                                 (float32_t)(222.2862),
                                 (float32_t)(-222.034));

            SPLL_1PH_NOTCH_config(&PFC1PHTTPL_spll2,
                                  PFC1PHTTPL_sine_mains.acFreq,
                                  PFC1PHTTPL_CONTROL_ISR_FREQUENCY,
                                  (float32_t)(222.2862),
                                  (float32_t)(-222.034),
                                  (float32_t) 0.25,
                                  (float32_t) 0.00001);

            SPLL_1PH_SOGI_FLL_config(&PFC1PHTTPL_spll3,
                                     PFC1PHTTPL_sine_mains.acFreq,
                                     PFC1PHTTPL_CONTROL_ISR_FREQUENCY,
                                     (float32_t)(222.2862),
                                     (float32_t)(-222.034),
                                     (float32_t) 0.5,
                                     (float32_t) 20000);

            computeNotchFltrCoeff( &PFC1PHTTPL_notch1,
                                   (float32_t)(PFC1PHTTPL_INSTRUMENTATION_ISR_FREQUENCY),
                                   (float32_t)(PFC1PHTTPL_sine_mains.acFreq*2.0f) ,
                                   0.25f,
                                   0.00001f);

            computeNotchFltrCoeff( &PFC1PHTTPL_notch2,
                                   (float32_t)(PFC1PHTTPL_INSTRUMENTATION_ISR_FREQUENCY) ,
                                   (float32_t)(PFC1PHTTPL_sine_mains.acFreq*2.0f) ,
                                   0.25f,
                                   0.00001f);

            PFC1PHTTPL_dutyPU=0.01f;

            PFC1PHTTPL_AQ_SW_FORCE_PWMxA_LOW_PWMxB_LOW(PFC1PHTTPL_LOW_FREQ_PWM_BASE);


            PFC1PHTTPL_SET_PWM_DBRED(PFC1PHTTPL_HIGH_FREQ_PWM_BASE,PFC1PHTTPL_PFC_PWM_PERIOD);
            PFC1PHTTPL_SET_PWM_DBFED(PFC1PHTTPL_HIGH_FREQ_PWM_BASE,PFC1PHTTPL_PFC_PWM_PERIOD);

            EINT;

            PFC1PHTTPL_nonLinearVoltageLoopFlag=0;

        }

        if(PFC1PHTTPL_autoStartSlew==3)
        {
            if(PFC1PHTTPL_guiVrms_Volts<150 )
            {
                PFC1PHTTPL_thetaOffset_pu=PFC1PHTTPL_LOW_LINE_INPUT_CAP_COMP_ADJUST;
            }
            else
            {
                PFC1PHTTPL_thetaOffset_pu=PFC1PHTTPL_HIGH_LINE_INPUT_CAP_COMP_ADJUST;
            }

            DINT;
            PFC1PHTTPL_HAL_clearPWMTripFlags(PFC1PHTTPL_LOW_FREQ_PWM_BASE);
            PFC1PHTTPL_HAL_clearPWMTripFlags(PFC1PHTTPL_HIGH_FREQ_PWM_BASE);
            PFC1PHTTPL_board_Status.enum_boardStatus=boardStatus_NoFault;
            EINT;

        }




    }
    else
    {
        PFC1PHTTPL_relayConnect=0;
        PFC1PHTTPL_autoStartSlew=0;
        PFC1PHTTPL_pwm_SwState.enum_pwmSwState=pwmSwState_defaultState;
        PFC1PHTTPL_closeGiLoop=0;
        PFC1PHTTPL_closeGvLoop=0;

    }
#endif

#if PFC1PHTTPL_DC_CHECK==1
    if(PFC1PHTTPL_autoStartSlew==100)//TODO:100
#else
    if(PFC1PHTTPL_autoStartSlew==4)
#endif
    {

        DINT;

        PFC1PHTTPL_vBusRefSlewed_pu=0;

        PFC1PHTTPL_gv.i6=0;
        PFC1PHTTPL_gv.i10=0;

        PFC1PHTTPL_gi.i10=0;
        PFC1PHTTPL_gi.i6=0;

        PFC1PHTTPL_closeGiLoop=0;
        PFC1PHTTPL_closeGvLoop=0;

        PFC1PHTTPL_firstTimeGvLoop=1;

        PFC1PHTTPL_stateSlew=0;
        PFC1PHTTPL_softStartDuty_ticks=0;

        PFC1PHTTPL_vBusRef_pu=PFC1PHTTPL_VBUS_TYPICAL_VOLT/PFC1PHTTPL_VDCBUS_MAX_SENSE_VOLT;

        PFC1PHTTPL_iLRef_pu=0.03;

        PFC1PHTTPL_iLRef_Inst_pu=0;
        PFC1PHTTPL_iLRef_Inst_prev_pu=0;

        PFC1PHTTPL_acSine=0;
        PFC1PHTTPL_acSine_Prev=0;

        PFC1PHTTPL_pwm_SwState.enum_pwmSwState=pwmSwState_normalOperation;

        EINT;

        PFC1PHTTPL_autoStartSlew++;

#if PFC1PHTTPL_DC_CHECK==1

        PFC1PHTTPL_HAL_clearPWMTripFlags(PFC1PHTTPL_LOW_FREQ_PWM_BASE);
        PFC1PHTTPL_HAL_clearPWMTripFlags(PFC1PHTTPL_HIGH_FREQ_PWM_BASE);

        PFC1PHTTPL_relayConnect=1;
        PFC1PHTTPL_closeGiLoop=1;

#endif

#if PFC1PHTTPL_INCR_BUILD == 3
        PFC1PHTTPL_closeGvLoop = 1;
#endif
    }
}


void PFC1PHTTPL_relayControl()
{
    if(PFC1PHTTPL_relay_count < 4)
    {
        PFC1PHTTPL_relay_count++;
    }

    if(PFC1PHTTPL_relay_count == 4)
    {
    #if PFC1PHTTPL_DC_CHECK==0
        if(PFC1PHTTPL_guiVrms_Volts > 75.0f || PFC1PHTTPL_guiVbus_Volts > 110.0f)//TODO:75
        {
            PFC1PHTTPL_relayConnect=1;
        }
        else
        {
            PFC1PHTTPL_relayConnect=0;
        }
    #endif

    #if PFC1PHTTPL_DC_CHECK==0
        if(fabsf(PFC1PHTTPL_acSine)<0.05f)
        {
            if(PFC1PHTTPL_relayConnect==1)
            {
                PFC1PHTTPL_HAL_closeRelay();
            }
        }

        if (PFC1PHTTPL_relayConnect==0)
        {
            PFC1PHTTPL_HAL_openRelay();
        }
    #else
        if(PFC1PHTTPL_relayConnect==1)
        {
            PFC1PHTTPL_HAL_closeRelay();
        }
        else
        {
            PFC1PHTTPL_HAL_openRelay();
        }
    #endif
    }
}

void PFC1PHTTPL_monitorVariable()
{
    PFC1PHTTPL_IsrTicker++;
    if(PFC1PHTTPL_usShowCnt>100) PFC1PHTTPL_usShowCnt=0;
    PFC1PHTTPL_Watchvalue[PFC1PHTTPL_usShowCnt]=*PFC1PHTTPL_iqGraphIdTab1[PFC1PHTTPL_uGraphID];
    PFC1PHTTPL_Watchvalue1[PFC1PHTTPL_usShowCnt]=*PFC1PHTTPL_iqGraphIdTab1[PFC1PHTTPL_uGraphID2];

    if(PFC1PHTTPL_IsrTicker%PFC1PHTTPL_usShowDiv==0) PFC1PHTTPL_usShowCnt++;
    if(PFC1PHTTPL_IsrTicker>10000)  PFC1PHTTPL_IsrTicker=0;

}


//TODO calibrateOffset()
void PFC1PHTTPL_calibrateOffset(volatile float32_t *ac_cur_sensedOffset,float32_t k1, float32_t k2)
{
    int16_t offsetCalCounter=0;

    PFC1PHTTPL_HAL_enablePWMInterruptGeneration(PFC1PHTTPL_C28x_CONTROLISR_INTERRUPT_TRIG_PWM_BASE);

    offsetCalCounter=0;
    while(offsetCalCounter<20000)
    {
        if(EPWM_getEventTriggerInterruptStatus(
                PFC1PHTTPL_C28x_CONTROLISR_INTERRUPT_TRIG_PWM_BASE)==1)
        {
            if(offsetCalCounter>1000)
            {
                //
                //Offset of the inductor current sense
                //
                *ac_cur_sensedOffset =  k1* (*ac_cur_sensedOffset) +
                                        k2 * (PFC1PHTTPL_IL_FB_1) * PFC1PHTTPL_ADC_PU_SCALE_FACTOR;

            }
            EPWM_clearEventTriggerInterruptFlag(PFC1PHTTPL_C28x_CONTROLISR_INTERRUPT_TRIG_PWM_BASE);
            offsetCalCounter++;
        }
    }

    ADC_setPPBCalibrationOffset(ADCA_BASE,ADC_PPB_NUMBER1,(0*4096.0f));
    ADC_setPPBCalibrationOffset(ADCA_BASE,ADC_PPB_NUMBER2,(0*4096.0f));
    ADC_setPPBCalibrationOffset(ADCA_BASE,ADC_PPB_NUMBER3,(0*4096.0f));
}

//TODO PFC1PHTTPL_setupSFRA
#if PFC1PHTTPL_SFRA_TYPE!=PFC1PHTTPL_SFRA_DISABLED

void PFC1PHTTPL_setupSFRA(void)
{
    SFRA_F32_reset(&PFC1PHTTPL_sfra1);
    SFRA_F32_config(&PFC1PHTTPL_sfra1,
                    PFC1PHTTPL_SFRA_ISR_FREQ,
                    PFC1PHTTPL_SFRA_AMPLITUDE,
                    PFC1PHTTPL_SFRA_FREQ_LENGTH,
                    PFC1PHTTPL_SFRA_FREQ_START,
                    PFC1PHTTPL_SFRA_FREQ_STEP_MULTIPLY,
                    PFC1PHTTPL_plantMagVect,
                    PFC1PHTTPL_plantPhaseVect,
                    PFC1PHTTPL_olMagVect,
                    PFC1PHTTPL_olPhaseVect,
                    NULL,
                    NULL,
                    PFC1PHTTPL_freqVect,
                    1);

    SFRA_F32_resetFreqRespArray(&PFC1PHTTPL_sfra1);

    // Re-initialize the frequency array to make SFRA sweep go fast
    i=0;

    #if PFC1PHTTPL_SFRA_TYPE==PFC1PHTTPL_SFRA_CURRENT// current loop
        PFC1PHTTPL_sfra1.freqVect[i++]=PFC1PHTTPL_SFRA_FREQ_START;
        for(;i<PFC1PHTTPL_sfra1.vecLength;i++)
        {
            if(PFC1PHTTPL_sfra1.freqVect[i-1]<10)
                PFC1PHTTPL_sfra1.freqVect[i]=PFC1PHTTPL_sfra1.freqVect[i-1]+2;
            else if(PFC1PHTTPL_sfra1.freqVect[i-1]<50)
                PFC1PHTTPL_sfra1.freqVect[i]=PFC1PHTTPL_sfra1.freqVect[i-1]+10;
            else
                PFC1PHTTPL_sfra1.freqVect[i]=PFC1PHTTPL_sfra1.freqVect[i-1]*PFC1PHTTPL_sfra1.freqStep;
        }
    #else
        PFC1PHTTPL_sfra1.freqVect[0]=2;
        PFC1PHTTPL_sfra1.freqVect[1]=4;
        PFC1PHTTPL_sfra1.freqVect[2]=6;
        PFC1PHTTPL_sfra1.freqVect[3]=8;
        PFC1PHTTPL_sfra1.freqVect[4]=10;
        PFC1PHTTPL_sfra1.freqVect[5]=12;
        PFC1PHTTPL_sfra1.freqVect[6]=14;
        PFC1PHTTPL_sfra1.freqVect[7]=16;
        PFC1PHTTPL_sfra1.freqVect[8]=18;
        PFC1PHTTPL_sfra1.freqVect[9]=20;
        PFC1PHTTPL_sfra1.freqVect[10]=22;
        PFC1PHTTPL_sfra1.freqVect[11]=24;
        PFC1PHTTPL_sfra1.freqVect[12]=26;
        PFC1PHTTPL_sfra1.freqVect[13]=28;
        PFC1PHTTPL_sfra1.freqVect[14]=30;
        PFC1PHTTPL_sfra1.freqVect[15]=35;
        PFC1PHTTPL_sfra1.freqVect[16]=40;
        PFC1PHTTPL_sfra1.freqVect[17]=45;
        PFC1PHTTPL_sfra1.freqVect[18]=55;
        PFC1PHTTPL_sfra1.freqVect[19]=65;
        PFC1PHTTPL_sfra1.freqVect[20]=70;
        PFC1PHTTPL_sfra1.freqVect[21]=80;
        PFC1PHTTPL_sfra1.freqVect[22]=90;
        PFC1PHTTPL_sfra1.freqVect[23]=130;
        PFC1PHTTPL_sfra1.freqVect[24]=140;
        PFC1PHTTPL_sfra1.freqVect[25]=150;
        PFC1PHTTPL_sfra1.freqVect[26]=160;
        PFC1PHTTPL_sfra1.freqVect[27]=170;
        PFC1PHTTPL_sfra1.freqVect[28]=210;
        PFC1PHTTPL_sfra1.freqVect[29]=250;
    #endif

    SFRA_GUI_config(PFC1PHTTPL_SFRA_GUI_SCI_BASE,
                    PFC1PHTTPL_SCI_VBUS_CLK,
                    PFC1PHTTPL_SFRA_GUI_SCI_BAUDRATE,
                    PFC1PHTTPL_SFRA_GUI_SCIRX_GPIO,
                    PFC1PHTTPL_SFRA_GUI_SCIRX_GPIO_PIN_CONFIG,
                    PFC1PHTTPL_SFRA_GUI_SCITX_GPIO,
                    PFC1PHTTPL_SFRA_GUI_SCITX_GPIO_PIN_CONFIG,
                    PFC1PHTTPL_SFRA_GUI_LED_INDICATOR,
                    PFC1PHTTPL_SFRA_GUI_LED_GPIO,
                    PFC1PHTTPL_SFRA_GUI_LED_GPIO_PIN_CONFIG,
                    &PFC1PHTTPL_sfra1,
                    1);

}

#endif

