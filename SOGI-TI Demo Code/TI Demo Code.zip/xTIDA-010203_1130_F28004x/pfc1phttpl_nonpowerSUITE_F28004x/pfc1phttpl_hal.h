/* ============================================================================
System Name:

File Name:      <BoardName>_board.h

Target:         TIDM-1007, F28004x

Author:

Description:    This file consists of common variables and functions
                for a particular hardware board, like functions to read current
                and voltage signals on the board and functions to setup the
                basic peripherals of the board
                This file must be settings independent, all settings dependent
                code should reside in the parent solution project.
===========================================================================  */
//#############################################################################
// $TI Release: TIDM_1007 v1.01.01.00 $
// $Release Date: Mon Nov  5 15:41:10 CST 2018 $
// $Copyright:
// Copyright (C) 2018 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################

#ifndef PFC1PH3ILTTPL_BOARD_H
#define PFC1PH3ILTTPL_BOARD_H

#ifdef __cplusplus

extern "C" {
#endif


//*****************************************************************************
// the includes
//*****************************************************************************
// Include files for device support, F2806x in this case
#include "inc/hw_types.h"
#include "driverlib.h"
#include "device.h"
#include <pfc1phttpl_settings.h>

//*****************************************************************************
//defines
//*****************************************************************************

// Timer definitions based on System Clock
// 150 MHz devices
#define     mSec0_5     0.5*SYSTEM_FREQUENCY*1000       // 0.5 mS
#define     mSec1       1*SYSTEM_FREQUENCY*1000         // 1.0 mS
#define     mSec2       2.0*SYSTEM_FREQUENCY*1000       // 2.0 mS
#define     mSec5       5*SYSTEM_FREQUENCY*1000         // 5.0 mS
#define     mSec7_5     7.5*SYSTEM_FREQUENCY*1000       // 7.5 mS
#define     mSec10      10*SYSTEM_FREQUENCY*1000        // 10 mS
#define     mSec20      20*SYSTEM_FREQUENCY*1000        // 20 mS
#define     mSec50      50*SYSTEM_FREQUENCY*1000        // 50 mS
#define     mSec100     100*SYSTEM_FREQUENCY*1000       // 100 mS
#define     mSec500     500*SYSTEM_FREQUENCY*1000       // 500 mS
#define     mSec1000    1000*SYSTEM_FREQUENCY*1000      // 1000 mS

#ifndef TRUE
#define FALSE 0
#define TRUE  1
#endif

/*******************************HAL_ADC*******************************/
//ADC result
#define PFC1PHTTPL_VBUS_FB_1     ADC_readResult(PFC1PHTTPL_VBUS_ADCRESULTREGBASE,PFC1PHTTPL_VBUS_ADC_SOC_NO_1)
#define PFC1PHTTPL_VBUS_FB_2     ADC_readResult(PFC1PHTTPL_VBUS_ADCRESULTREGBASE,PFC1PHTTPL_VBUS_ADC_SOC_NO_2)

#define PFC1PHTTPL_IL_FB_1       ADC_readResult(PFC1PHTTPL_IL_ADCRESULTREGBASE,PFC1PHTTPL_IL_ADC_SOC_NO_1)
#define PFC1PHTTPL_IL_FB_2       ADC_readResult(PFC1PHTTPL_IL_ADCRESULTREGBASE,PFC1PHTTPL_IL_ADC_SOC_NO_2)

#define PFC1PHTTPL_IL_VREF_FB_1  ADC_readResult(PFC1PHTTPL_IL_VREF_ADCRESULTREGBASE,PFC1PHTTPL_IL_VREF_ADC_SOC_NO_1)
#define PFC1PHTTPL_IL_VREF_FB_2  ADC_readResult(PFC1PHTTPL_IL_VREF_ADCRESULTREGBASE,PFC1PHTTPL_IL_VREF_ADC_SOC_NO_2)

#define PFC1PHTTPL_VAC_L_FB_1    ADC_readResult(PFC1PHTTPL_VACL_ADCRESULTREGBASE,PFC1PHTTPL_VACL_ADC_SOC_NO_1)
#define PFC1PHTTPL_VAC_L_FB_2    ADC_readResult(PFC1PHTTPL_VACL_ADCRESULTREGBASE,PFC1PHTTPL_VACL_ADC_SOC_NO_2)

#define PFC1PHTTPL_VAC_N_FB_1    ADC_readResult(PFC1PHTTPL_VACN_ADCRESULTREGBASE,PFC1PHTTPL_VACN_ADC_SOC_NO_1)
#define PFC1PHTTPL_VAC_N_FB_2    ADC_readResult(PFC1PHTTPL_VACN_ADCRESULTREGBASE,PFC1PHTTPL_VACN_ADC_SOC_NO_2)
//ADC scale factor
#define PFC1PHTTPL_ADC_PU_SCALE_FACTOR      (float32_t)(0.000244140625)//1/4096
#define PFC1PHTTPL_ADC_PU_PPB_SCALE_FACTOR  (float32_t)(0.000488281250)//1/2^11

/*******************************HAL_Timer*******************************/
#define PFC1PHTTPL_GET_TASK_A_TIMER_OVERFLOW_STATUS CPUTimer_getTimerOverflowStatus(CPUTIMER0_BASE)
#define PFC1PHTTPL_CLEAR_TASK_A_TIMER_OVERFLOW_FLAG CPUTimer_clearOverflowFlag(CPUTIMER0_BASE)

#define PFC1PHTTPL_GET_TASK_B_TIMER_OVERFLOW_STATUS CPUTimer_getTimerOverflowStatus(CPUTIMER1_BASE)
#define PFC1PHTTPL_CLEAR_TASK_B_TIMER_OVERFLOW_FLAG CPUTimer_clearOverflowFlag(CPUTIMER1_BASE)
/*******************************HAL_EPWM*******************************/
#define PFC1PHTTPL_DISABLE_AQ_SW_FRC(m)                HWREGH(m + EPWM_O_AQCSFRC) = 0x00;
#define PFC1PHTTPL_AQ_SW_FORCE_PWMxA_HIGH_PWMxB_LOW(m) HWREGH(m + EPWM_O_AQCSFRC) = 0x06;
#define PFC1PHTTPL_AQ_SW_FORCE_PWMxA_LOW_PWMxB_HIGH(m) HWREGH(m + EPWM_O_AQCSFRC) = 0x09;
#define PFC1PHTTPL_AQ_SW_FORCE_PWMxA_LOW_PWMxB_LOW(m)  HWREGH(m + EPWM_O_AQCSFRC) = 0x05;
#define PFC1PHTTPL_SET_PWM_DBRED(m,n)                  HWREGH(m + EPWM_O_DBRED ) = n;
#define PFC1PHTTPL_SET_PWM_DBFED(m,n)                  HWREGH(m + EPWM_O_DBFED ) = n;
#define PFC1PHTTPL_ENABLE_SWAP_DEADBAND_OUTPUT(m)      HWREGH(m + EPWM_O_DBCTL) = (HWREGH(m + EPWM_O_DBCTL) | 0x3000);
#define PFC1PHTTPL_DISABLE_SWAP_DEADBAND_OUTPUT(m)     HWREGH(m + EPWM_O_DBCTL) = (HWREGH(m + EPWM_O_DBCTL) & ~0x3000);
#define PFC1PHTTPL_PWM_TRIP_STATUS                     EPWM_getTripZoneFlagStatus

//*****************************************************************************
// the function prototypes
//*****************************************************************************
void PFC1PHTTPL_HAL_setupDevice(void);

void PFC1PHTTPL_HAL_setupADC(void);

void PFC1PHTTPL_HAL_setupPFC1phttplPWM(uint32_t base1, uint32_t base3,uint16_t pwm_period_ticks,
                                       uint16_t pwm_dbred_ticks, uint16_t pwm_dbfed_ticks);
void PFC1PHTTPL_HAL_disablePWMCLKCounting(void);
void PFC1PHTTPL_HAL_enablePWMCLKCounting(void);
void PFC1PHTTPL_HAL_setupEPWMtoTriggerADCSOC(uint32_t base);
void PFC1PHTTPL_HAL_setPinsAsPWM();

void PFC1PHTTPL_HAL_setupBoardProtection(uint32_t base1, uint32_t base3,
                                         float32_t current_limit, float32_t current_max_sense);
void PFC1PHTTPL_HAL_setupCMPSS(uint32_t base1, float32_t current_limit, float32_t current_max_sense);

void PFC1PHTTPL_HAL_setupProfilingGPIO(void);
void PFC1PHTTPL_HAL_setupRelayGPIO(void);
void PFC1PHTTPL_HAL_toggleLED(void);
void PFC1PHTTPL_HAL_setupLEDGPIO(void);
void PFC1PHTTPL_HAL_setupGainChangeGPIO(void);
void PFC1PHTTPL_HAL_setupStartupGPIO(void);

void PFC1PHTTPL_HAL_setupCLA(void);

//CLA C Tasks defined in Cla1Tasks_C.cla
__attribute__((interrupt))  void Cla1Task1();
__attribute__((interrupt))  void Cla1Task2();
__attribute__((interrupt))  void Cla1Task3();
__attribute__((interrupt))  void Cla1Task4();
__attribute__((interrupt))  void Cla1Task5();
__attribute__((interrupt))  void Cla1Task6();
__attribute__((interrupt))  void Cla1Task7();
__attribute__((interrupt))  void Cla1BackgroundTask();

extern uint16_t Cla1ProgLoadStart;
extern uint16_t Cla1ProgLoadEnd;
extern uint16_t Cla1ProgLoadSize;
extern uint16_t Cla1ProgRunStart;
extern uint16_t Cla1ProgRunEnd;
extern uint16_t Cla1ProgRunSize;

// ISR related
#if PFC1PHTTPL_CONTROL_RUNNING_ON == C28x_CORE

#ifndef __TMS320C28XX_CLA__
    #pragma INTERRUPT (controlISR, HPI)
    #pragma CODE_SECTION(controlISR,"isrcodefuncs");
    interrupt void controlISR(void);
    inline void PFC1PHTTPL_HAL_clearInterrupt(uint16_t pie_group_no);
    inline void PFC1PHTTPL_HAL_setupInterrupt(void);
#endif

#endif

#if PFC1PHTTPL_INSTRUMENTATION_ISR_RUNNING_ON == C28x_CORE

#ifndef __TMS320C28XX_CLA__
    #pragma CODE_SECTION(tenKHzISR,"ramfuncs");
    interrupt void tenKHzISR(void);
    inline void PFC1PHTTPL_HAL_clearInterrupt(uint16_t pie_group_no);
    inline void PFC1PHTTPL_HAL_setupInterrupt(void);
#endif

#endif

//*****************************************************************************
// Inline functions
//*****************************************************************************

static inline void PFC1PHTTPL_HAL_EPWM_setCounterCompareValueOptimized
                    (uint32_t base,EPWM_CounterCompareModule compModule,
                     uint16_t compCount)
{
    uint32_t registerOffset;

    // Get the register offset for the Counter compare
    registerOffset = EPWM_O_CMPA + (uint16_t)compModule;
    // Write to the counter compare registers.
    #pragma diag_suppress=770
    #pragma diag_suppress=173
    if((compModule == EPWM_COUNTER_COMPARE_A) ||
    (compModule == EPWM_COUNTER_COMPARE_B))
    {
        // write to CMPA or COMPB bits
        HWREGH(base + registerOffset + 1) = (uint16_t)compCount;
    }
    else
    { // write to COMPC or COMPD bits
        HWREGH(base + registerOffset) = compCount;
    }
    #pragma diag_warning=770
    #pragma diag_warning=173
}


//TODO updatePFCPWM()
inline void PFC1PHTTPL_HAL_update_pfc1phttplPWM(uint32_t base1, uint32_t base3,
                                    float32_t duty, float32_t phase2ScaleFactor)
{
    uint32_t dutyPWMReg;

    dutyPWMReg= (uint32_t)((float32_t)(PFC1PHTTPL_PFC_PWM_PERIOD/2.0f) * fabsf(duty));

    PFC1PHTTPL_HAL_EPWM_setCounterCompareValueOptimized(base3,EPWM_COUNTER_COMPARE_A,
                   (uint32_t)((float32_t)dutyPWMReg*(float32_t)phase2ScaleFactor));


}

//TODO setProfilingGPIO
inline void PFC1PHTTPL_HAL_setProfilingGPIO(void)
{
    #pragma diag_suppress=770
    #pragma diag_suppress=173
    HWREG(GPIODATA_BASE  + GPIO_O_GPASET ) = PFC1PHTTPL_GPIO_PROFILING1_SET;
    #pragma diag_warning=770
    #pragma diag_warning=173
}

//TODO resetProfilingGPIO
inline void PFC1PHTTPL_HAL_resetProfilingGPIO(void)
{
    #pragma diag_suppress=770
    #pragma diag_suppress=173
    HWREG(GPIODATA_BASE  + GPIO_O_GPACLEAR ) = PFC1PHTTPL_GPIO_PROFILING1_CLEAR;
    #pragma diag_warning=770
    #pragma diag_warning=173
}

//TODO setProfilingGPIO2
inline void PFC1PHTTPL_HAL_setProfilingGPIO2(void)
{
    #pragma diag_suppress=770
    #pragma diag_suppress=173
    HWREG(GPIODATA_BASE  + GPIO_O_GPASET ) = PFC1PHTTPL_GPIO_PROFILING2_SET;
    #pragma diag_warning=770
    #pragma diag_warning=173
}

//TODO resetProfilingGPIO2
inline void PFC1PHTTPL_HAL_resetProfilingGPIO2(void)
{
    #pragma diag_suppress=770
    #pragma diag_suppress=173
    HWREG(GPIODATA_BASE  + GPIO_O_GPACLEAR ) = PFC1PHTTPL_GPIO_PROFILING2_CLEAR;
    #pragma diag_warning=770
    #pragma diag_warning=173
}

//TODO gainHighSetforLowCurrent
inline void PFC1PHTTPL_HAL_gainHighSetforLowCurrent(void)
{
    GPIO_writePin(PFC1PHTTPL_GPIO_I_SENSE_GAIN_ADJUST,1);
}

//TODO gainLowSetforHighCurrent
inline void PFC1PHTTPL_HAL_gainLowSetforHighCurrent(void)
{
    GPIO_writePin(PFC1PHTTPL_GPIO_I_SENSE_GAIN_ADJUST,0);
}

//TODO closeRelay
inline void PFC1PHTTPL_HAL_closeRelay(void)
{
    GPIO_writePin(PFC1PHTTPL_GPIO_RELAY,1);
}

//TODO openRelay
inline void PFC1PHTTPL_HAL_openRelay(void)
{
    GPIO_writePin(PFC1PHTTPL_GPIO_RELAY,0);
}

//TODO Do not start LLC
inline void PFC1PHTTPL_HAL_stopStartLLC(void)
{
    GPIO_writePin(PFC1PHTTPL_GPIO_START_LLC,1);
}

//TODO Start LLC
inline void PFC1PHTTPL_HAL_startLLC(void)
{
    GPIO_writePin(PFC1PHTTPL_GPIO_START_LLC,0);
}

//TODO shutDown LLC
inline void PFC1PHTTPL_HAL_shutDownLLC(void)
{
    GPIO_writePin(PFC1PHTTPL_GPIO_SHUTDOWN_LLC, 1);
}

//TODO shutDown LLC
inline void PFC1PHTTPL_HAL_stopShutDownLLC(void)
{
    GPIO_writePin(PFC1PHTTPL_GPIO_SHUTDOWN_LLC, 0);
}

//TODO Light up LED2
inline void PFC1PHTTPL_HAL_lightUpLED2(void)
{
   GPIO_writePin(PFC1PHTTPL_GPIO_LED2, 1);
}

//TODO clearPWMTrip
inline void PFC1PHTTPL_HAL_clearPWMTripFlags(uint32_t base)
{
    // clear all the configured trip sources for the PWM module
    EPWM_clearTripZoneFlag(base,
                           ( EPWM_TZ_INTERRUPT_OST |
                             EPWM_TZ_INTERRUPT_CBC |
                             EPWM_TZ_INTERRUPT_DCAEVT1 )
                           );
}

inline void PFC1PHTTPL_HAL_clearOSTPWMTripFlag(uint32_t base)
{
    // clear all the configured trip sources for the PWM module
    EPWM_clearTripZoneFlag(base,EPWM_TZ_INTERRUPT_OST);
}

inline void PFC1PHTTPL_HAL_forceOSTPWMTrip(uint32_t base)
{
    EPWM_forceTripZoneEvent(base,EPWM_TZ_FORCE_EVENT_OST);
}

//TODO clearPWM Interrupt Flag
inline void PFC1PHTTPL_HAL_clearPWMInterruptFlag(uint32_t base)
{
    EPWM_clearEventTriggerInterruptFlag(base);
}

//TODO enable PWM Interrupt generation
inline void PFC1PHTTPL_HAL_enablePWMInterruptGeneration(uint32_t base)
{
    EPWM_setCounterCompareValue(base,EPWM_COUNTER_COMPARE_B,(50/2));
    EPWM_setInterruptSource(base,EPWM_INT_TBCTR_D_CMPB);
    EPWM_setInterruptEventCount(base,PFC1PHTTPL_CNTRL_ISR_FREQ_RATIO);
    EPWM_enableInterrupt(base);
    EPWM_clearEventTriggerInterruptFlag(base);
}


#ifndef __TMS320C28XX_CLA__
//TODO clearInterrupt
inline void PFC1PHTTPL_HAL_clearInterrupt(uint16_t pie_group_no)
{
    Interrupt_clearACKGroup(pie_group_no);
}


inline void PFC1PHTTPL_HAL_setupInterrupt(void)
{
    CPUTimer_enableInterrupt(
            PFC1PHTTPL_C28x_INSTRUMENTATION_INTERRUPT_TRIG_CPUTIMER_BASE
            );
    CPUTimer_clearOverflowFlag(
            PFC1PHTTPL_C28x_INSTRUMENTATION_INTERRUPT_TRIG_CPUTIMER_BASE
            );

#if PFC1PHTTPL_CONTROL_RUNNING_ON == C28x_CORE
    Interrupt_register(PFC1PHTTPL_C28x_CONTROLISR_INTERRUPT, &controlISR);
    PFC1PHTTPL_HAL_enablePWMInterruptGeneration(PFC1PHTTPL_C28x_CONTROLISR_INTERRUPT_TRIG_PWM_BASE);
    PFC1PHTTPL_HAL_clearInterrupt(PFC1PHTTPL_C28x_CONTROLISR_INTERRUPT_PIE_GROUP_NO);
    Interrupt_enable(PFC1PHTTPL_C28x_CONTROLISR_INTERRUPT);
#endif

#if PFC1PHTTPL_INSTRUMENTATION_ISR_RUNNING_ON == C28x_CORE
    Interrupt_register(PFC1PHTTPL_C28x_INSTRUMENTATION_INTERRUPT, &tenKHzISR);
    Interrupt_enable(PFC1PHTTPL_C28x_INSTRUMENTATION_INTERRUPT);
#endif

#if (PFC1PHTTPL_CONTROL_RUNNING_ON==CLA_CORE || PFC1PHTTPL_INSTRUMENTATION_ISR_RUNNING_ON==CLA_CORE)
    PFC1PHTTPL_HAL_setupCLA();
#endif

    EALLOW;
    //
    //Enable Global interrupt INTM.
    //Enable Global realtime interrupt DBGM
    //
    EINT;
    ERTM;
    EDIS;
}

#endif

#ifdef __cplusplus
}
#endif                                  /* extern "C" */


#endif
