/* ============================================================================
System Name:	Totem Pole Bridgeless CCM PFC (TIDM-1007)

File Name:	  	pfc1ph3ilttpl.c

Author:			Manish Bhardwaj, 7/13/2018

Description:	This is the solution file, following is the description of
                other files that are used by this system
				<solution>.c -> solution source file
				<solution>.h -> solution header file
				<solution>_settings.h -> powerSUITE generated settings
				<boad name>_board.c -> board drivers source file
				<boad name>_board.h -> board drivers header file

                <optional>
 			    <solution>_cla.cla -> cla task file
                <solution>_cla.h -> cla task header file
===========================================================================  */
//#############################################################################
// $TI Release: TIDM_1007 v1.01.01.00 $
// $Release Date: Mon Nov  5 15:41:10 CST 2018 $
// $Copyright:
// Copyright (C) 2018 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################


//*****************************************************************************
// the includes
//*****************************************************************************

#include <pfc1phttpl.h>

//*********************** C2000 SYSTEM SW FRAMEWORK  ************************//

//
//---  State Machine Related ---
//
int16_t vTimer0[4];         // Virtual Timers slaved off CPU Timer 0 (A events)
int16_t vTimer1[4];         // Virtual Timers slaved off CPU Timer 1 (B events)

// Variable declarations for state machine
void (*Alpha_State_Ptr)(void);  // Base States pointer
void (*A_Task_Ptr)(void);       // State pointer A branch
void (*B_Task_Ptr)(void);       // State pointer B branch

// State Machine function prototypes
//------------------------------------
// Alpha states
void A0(void);  //state A0
void B0(void);  //state B0
// A branch states
void A1(void);  //state A1
// B branch states
void B1(void);  //state B1
void B2(void);  //state B2
void B3(void);  //state B3

//TODO Main
void main(void)
{
    //
	// This routine sets up the basic device configuration such as
    // initializing PLL, copying code from FLASH to RAM,
	// this routine will also initialize the CPU timers that are used in
    // the background task for this system
	//
    PFC1PHTTPL_HAL_setupDevice();//PFC1PHTTPL

	//
    // Tasks State-machine init
	//
    Alpha_State_Ptr = &A0;
	A_Task_Ptr = &A1;
	B_Task_Ptr = &B1;

	//
	// Stop all PWM mode clock
	//
	PFC1PHTTPL_HAL_disablePWMCLKCounting();

	//
	//Sets up PWM for BRIDGELESS PFC. PWM1 is for low side, PWM3 is for high side
	//
	PFC1PHTTPL_HAL_setupPFC1phttplPWM(PFC1PHTTPL_LOW_FREQ_PWM_BASE,PFC1PHTTPL_HIGH_FREQ_PWM_BASE,PFC1PHTTPL_PFC_PWM_PERIOD,
	                                  PFC1PHTTPL_HIGH_FREQ_PWM_DEADBAND_RED_COUNT,PFC1PHTTPL_HIGH_FREQ_PWM_DEADBAND_FED_COUNT);

	//
	// power up ADC on the device
	//
	PFC1PHTTPL_HAL_setupADC();

    //
    //Configure profiling GPIO
    //
	PFC1PHTTPL_HAL_setupProfilingGPIO();

    //
    //Configure LED GPIO
    //
	PFC1PHTTPL_HAL_setupLEDGPIO();

    //
    //Configure relay GPIO
    //
	PFC1PHTTPL_HAL_setupRelayGPIO();

    //
    //Configure gain change GPIO and current sample gain
    //
	PFC1PHTTPL_HAL_setupGainChangeGPIO();
	PFC1PHTTPL_HAL_gainHighSetforLowCurrent();

    //
    //Configure LLC start-up flag GPIO
    //
	PFC1PHTTPL_HAL_stopStartLLC();
	PFC1PHTTPL_HAL_setupStartupGPIO();

    //
    // Initialize global variables generic to the board like ones used to
    // read current values etc
    //
	PFC1PHTTPL_globalVariablesInit();

	//
    //Setup SFRA
	//
	#if PFC1PHTTPL_SFRA_TYPE==PFC1PHTTPL_SFRA_DISABLED
    #else
	    PFC1PHTTPL_setupSFRA();
    #endif

    //
    // Enable PWM Clocks
    //
	PFC1PHTTPL_HAL_enablePWMCLKCounting();

    //
    //Set up PWM trigger ADC conversion.
    //
	PFC1PHTTPL_HAL_setupEPWMtoTriggerADCSOC(PFC1PHTTPL_HIGH_FREQ_PWM_BASE);

	//
	//Offset Calibration Routine  PFC1PHTTPL_iLMeasOffset_pu=498000056;
	//
	PFC1PHTTPL_calibrateOffset(&PFC1PHTTPL_iLMeasOffset_pu, PFC1PHTTPL_k1, PFC1PHTTPL_k2);

    //
	// setup protection and trips for the board
	//
    #if PFC1PHTTPL_DEBUG == 1
	PFC1PHTTPL_HAL_setupBoardProtection(PFC1PHTTPL_LOW_FREQ_PWM_BASE, PFC1PHTTPL_HIGH_FREQ_PWM_BASE,
	                                    PFC1PHTTPL_IL_TRIP_LIMIT_AMPS, PFC1PHTTPL_IL_MAX_SENSE_AMPS);
    #endif

	//
	//safe to setup PWM pins
	//
	PFC1PHTTPL_HAL_setPinsAsPWM();

	//
	//ISR Mapping
	//
	PFC1PHTTPL_HAL_setupInterrupt();

    //
    // IDLE loop. Just sit and loop forever, periodically will branch into
    // A0-A3, B0-B3, C0-C3 tasks
    // Frequency of this branching is set in setupDevice routine:
    //
	for(;;)
	{
		// State machine entry & exit point
		//===========================================================
		(*Alpha_State_Ptr)();	// jump to an Alpha state (A0,B0,...)
		//===========================================================
		if(PFC1PHTTPL_initializationFlag == 1)
		{

		    PFC1PHTTPL_initializationFlag = 0;
			PFC1PHTTPL_sfra1.start = 1;
		}
//TODO:
		if(PFC1PHTTPL_guiVbus_Volts<PFC1PHTTPL_guiVbusMax_Volts && PFC1PHTTPL_guiVbus_Volts>378 )
		{
		    PFC1PHTTPL_HAL_startLLC();//this is start up flag
		}
		else
		{
		    PFC1PHTTPL_HAL_stopStartLLC();
		}

	}
} //END MAIN CODE



//TODO control ISR Code
#if PFC1PHTTPL_CONTROL_RUNNING_ON == C28x_CORE
interrupt void controlISR(void)
{
    PFC1PHTTPL_HAL_setProfilingGPIO();
    //PFC1PHTTPL_monitorVariable();
    PFC1PHTTPL_pfcControlCode();
    PFC1PHTTPL_HAL_clearInterrupt(PFC1PHTTPL_C28x_CONTROLISR_INTERRUPT_PIE_GROUP_NO);
}
#endif

//TODO 10Khz ISR Code
#if PFC1PHTTPL_INSTRUMENTATION_ISR_RUNNING_ON == C28x_CORE
interrupt void tenKHzISR(void)
{
    PFC1PHTTPL_voltageLoopPlusInstrumentationCode();
}
#endif

//=============================================================================
//	STATE-MACHINE SEQUENCING AND SYNCRONIZATION FOR SLOW BACKGROUND TASKS
//=============================================================================

//--------------------------------- FRAME WORK --------------------------------
void A0(void)
{
	//
    // loop rate synchronizer for A-tasks
	//
    if(PFC1PHTTPL_GET_TASK_A_TIMER_OVERFLOW_STATUS == 1)
	{
        PFC1PHTTPL_CLEAR_TASK_A_TIMER_OVERFLOW_FLAG;	// clear flag

		//-----------------------------------------------------------
		(*A_Task_Ptr)();		// jump to an A Task (A1,A2,A3,...)
		//-----------------------------------------------------------

		vTimer0[0]++;			// virtual timer 0, instance 0 (spare)
	}

    //
	// PFC1PHTTPL_relayControl();
	// Comment out to allow only A tasks
	//
	Alpha_State_Ptr = &B0;
}

void B0(void)
{
	//
    // loop rate synchronizer for B-tasks
	//
    if(PFC1PHTTPL_GET_TASK_B_TIMER_OVERFLOW_STATUS  == 1)
	{
        PFC1PHTTPL_CLEAR_TASK_B_TIMER_OVERFLOW_FLAG;				// clear flag

		//-----------------------------------------------------------
		(*B_Task_Ptr)();		// jump to a B Task (B1,B2,B3,...)
		//-----------------------------------------------------------

		vTimer1[0]++;			// virtual timer 1, instance 0 (spare)
	}

	//
	// Allow A state tasks
	//
	Alpha_State_Ptr = &A0;
}

//=============================================================================
//	A - TASKS (executed in every 10 msec)
//=============================================================================
//--------------------------------------------------------
void A1(void)
//--------------------------------------------------------
{
#if PFC1PHTTPL_SFRA_TYPE!=PFC1PHTTPL_SFRA_DISABLED
    SFRA_F32_runBackgroundTask(&PFC1PHTTPL_sfra1);
    SFRA_GUI_runSerialHostComms(&PFC1PHTTPL_sfra1);
#endif

	//-------------------
	//the next time CpuTimer0 'counter' reaches Period value go to A2
	A_Task_Ptr = &A1;
	//-------------------
}

//=============================================================================
//	B - TASKS (executed in every 100 msec)
//=============================================================================

//----------------------------------- USER ------------------------------------

//----------------------------------------
void B1(void)
//----------------------------------------
{
    PFC1PHTTPL_updateBoardStatus();
	PFC1PHTTPL_updateBuildLevel();
	//-----------------
	//the next time CpuTimer1 'counter' reaches Period value go to B2
	B_Task_Ptr = &B2;
	//-----------------
}

//----------------------------------------
void B2(void) //  SPARE
//----------------------------------------
{

    PFC1PHTTPL_autoStartPFC();
	//-----------------
	//the next time CpuTimer1 'counter' reaches Period value go to B3
	B_Task_Ptr = &B3;
	//-----------------
}

//----------------------------------------
void B3(void) //  SPARE
//----------------------------------------
{
    PFC1PHTTPL_HAL_toggleLED();
	//-----------------
	//the next time CpuTimer1 'counter' reaches Period value go to B1
	B_Task_Ptr = &B1;
	//-----------------
}


//===========================================================================
// No more.
//===========================================================================
