//AddWatchWindowVars Build 2
expRemoveAll()
//Variables
expAdd ("PFC1PHTTPL_build_Level.enum_buildLevel",getNatural())
expAdd ("PFC1PHTTPL_board_Status.enum_boardStatus",getNatural())
expAdd ("clearTrip", getNatural())
expAdd ("PFC1PHTTPL_closeGiLoop", getNatural())
expAdd ("PFC1PHTTPL_iLRef_pu",getNatural())
expAdd ("PFC1PHTTPL_iLMeas_pu",getNatural())
expAdd ("PFC1PHTTPL_iLMeasOffset_pu",getNatural())
expAdd ("PFC1PHTTPL_guiVbus_Volts",getNatural())
expAdd ("PFC1PHTTPL_guiVin_Volts",getNatural())
expAdd ("PFC1PHTTPL_guiIL_Amps",getNatural())
expAdd ("EPwm1Regs.TZFLG",getNatural())
expAdd ("EPwm2Regs.TZFLG",getNatural())
expAdd ("PFC1PHTTPL_dutyPU",getNatural())
expAdd ("PFC1PHTTPL_dutyPU_DC",getNatural())
expAdd ("PFC1PHTTPL_autoStartSlew",getNatural())


