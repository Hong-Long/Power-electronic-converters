//AddWatchWindowVars
expRemoveAll()
//Variables
expAdd ("PFC1PHTTPL_build_Level.enum_buildLevel",getNatural())
expAdd ("PFC1PHTTPL_pwm_SwState.enum_pwmSwState",getNatural())
expAdd ("PFC1PHTTPL_board_Status.enum_boardStatus",getNatural())
expAdd ("EPwm1Regs.TZFLG",getNatural())
expAdd ("EPwm3Regs.TZFLG",getNatural())
expAdd ("PFC1PHTTPL_closeGvLoop", getNatural())
expAdd ("PFC1PHTTPL_closeGiLoop", getNatural())
expAdd ("PFC1PHTTPL_vBusRef_pu",getNatural())
expAdd ("PFC1PHTTPL_vBusMeas_pu",getNatural())
expAdd ("PFC1PHTTPL_iLMeasOffset_pu",getNatural())
expAdd ("PFC1PHTTPL_guiVbus_Volts",getNatural())
expAdd ("PFC1PHTTPL_guiVin_Volts",getNatural())
expAdd ("PFC1PHTTPL_guiVrms_Volts",getNatural())
expAdd ("PFC1PHTTPL_guiIrms_Amps",getNatural())
expAdd ("PFC1PHTTPL_guiPrms_W",getNatural())
expAdd ("PFC1PHTTPL_guiPowerFactor",getNatural())
expAdd ("guiFreqAvg",getNatural())
expAdd ("PFC1PHTTPL_dutyPU",getNatural())
expAdd ("PFC1PHTTPL_dutyPU_DC",getNatural())
expAdd ("PFC1PHTTPL_autoStartSlew",getNatural())
expAdd ("PFC1PHTTPL_stateSlewMax",getNatural())
expAdd ("PFC1PHTTPL_gi",getNatural())






