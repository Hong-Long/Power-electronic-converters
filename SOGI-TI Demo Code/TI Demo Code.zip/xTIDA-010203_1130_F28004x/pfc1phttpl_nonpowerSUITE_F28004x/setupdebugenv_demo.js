//AddWatchWindowVars
expRemoveAll()
expAdd ("guiInvStart",getNatural())
expAdd ("guiInvStop",getNatural())
expAdd ("PFC1PHTPPL_board_State.enum_boardState",getNatural())
expAdd ("PFC1PHTPPL_board_Status.enum_boardStatus",getNatural())
expAdd ("PFC1PHTPPL_build_Level.enum_buildLevel",getNatural())
expAdd ("PFC1PHTPPL_guiVbus_Volts",getNatural())
expAdd ("PFC1PHTPPL_guiPrms_W",getNatural())
expAdd ("PFC1PHTPPL_guiVrms_Volts",getNatural())
expAdd ("PFC1PHTPPL_guiIrms_Amps",getNatural())
expAdd ("guiVo",getNatural())
expAdd ("PFC1PHTPPL_guiIL_Amps",getNatural())
expAdd ("guiFreqAvg",getNatural())
expAdd ("PFC1PHTPPL_guiVema_Volts",getNatural())
expAdd ("PFC1PHTPPL_guiPowerFactor",getNatural())




